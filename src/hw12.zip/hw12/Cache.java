package hw12;

public class Cache {
    private Account account;
    private boolean read, written, opened;
    private int initialValue, currentValue;

    public Cache(Account account) {
        this.account = account;
        read = false;
        written = false;
        initialValue = account.peek();
        currentValue = account.peek();
    }

    // TODO: This might be a problem
    public int peekCache() {
//        if (read || written) {
//            return currentValue;
//        } else { // not read yet
//            initialValue = account.peek();
//            currentValue = initialValue;
//            read = true;
//            return -1;
//        }
        read = true;
        return currentValue;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public void setWritten(boolean written) {
        this.written = written;
        //TODO: initialValue = peek()
    }

    public void setCache(int value) {
        written = true;
        currentValue = value;
    }

    public void openIfNeeded() throws TransactionAbortException {
        boolean readOrWrite = false;
        if (written) readOrWrite = true;
        if (read) readOrWrite = false;
        if (written || read)  {
            opened = true;
            account.open(readOrWrite);
        }
    }

    public void closeIfNeeded() {
        if (opened) account.close();
    }

    public void commit() {
        if (written) account.update(currentValue);
    }

    public void verify() throws TransactionAbortException{
        if (read && opened) {
        	account.verify(currentValue);
        }
    }
}
