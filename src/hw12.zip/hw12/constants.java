package hw12;

public class constants {
    public static final int A = 0;
    public static final int Z = 25;
    public static final int numLetters = 26;
}
