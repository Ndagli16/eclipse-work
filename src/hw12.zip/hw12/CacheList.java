package hw12;

/**
 * Singleton class to generate an array of Cachaes
 */
public class CacheList {
    private static CacheList singleton = null;

    private Cache[] caches;

    private CacheList (){
        caches = new Cache[constants.numLetters];
        for (int i = constants.A; i <= constants.Z; i ++) {
            caches[i] = new Cache(new Account(constants.Z - i));
        }
    }

    private static CacheList shared() {
        if (singleton == null) {
            singleton = new CacheList();
            return singleton;
        }
        return singleton;
    }

    public static Cache[] sharedCaches() {
        return CacheList.shared().caches;
    }
}
